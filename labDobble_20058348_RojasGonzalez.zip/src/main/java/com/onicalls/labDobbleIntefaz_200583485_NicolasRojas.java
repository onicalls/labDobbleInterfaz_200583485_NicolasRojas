package com.onicalls;

import com.onicalls.gui.MenuPrincipal;

/**
 * Dobble en el paradigma orientado a objetos
 * Alumno: Nicolás Rojas
 * Rut: 20.058.348-5
 * Profesor encargado:
 */

public class labDobbleIntefaz_200583485_NicolasRojas {
    public static void main(String[] args) {
        new MenuPrincipal().setVisible(true);
    }
}
