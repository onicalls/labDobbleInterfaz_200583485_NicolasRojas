package com.onicalls;

/**
 * Dobble en el paradigma orientado a objetos
 * Alumno: Nicolás Rojas
 * Rut: 20.058.348-5
 * Profesor encargado: Miguel Trufa
 */

public class labDobbleJava_200583485_NicolasRojas {
    public static void main(String[] args) {
        MenuPrincipal.mainMenu();
    }
}
