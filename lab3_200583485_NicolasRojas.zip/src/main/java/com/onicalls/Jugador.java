package com.onicalls;

/**
 * Intefaz Jugador que contiene los métodos que utilizará la clase Player.
 */
public interface Jugador {
    void addPoints(int points, int pointsToAdd);
}
