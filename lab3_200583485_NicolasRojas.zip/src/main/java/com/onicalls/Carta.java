package com.onicalls;

/**
 * Intefaz Carta que contiene los métodos que utilizará la clase Card.
 */
public interface Carta {
    void addElements(int element);
}
